// const open = document.getElementById('icon-menu');  // Bouton pour ouvrir le menu
// const close = document.getElementById('icone-close');  // Bouton pour fermer le menu
// const menu = document.getElementById('.navb');  // Élément représentant le menu

// console.log(open);


// Ajoute un écouteur d'événement 'click' au bouton 'open-menu'
// open.addEventListener('click', (e) => {
//     // Affiche le menu en supprimant la classe 'hidden' et affiche le bouton 'close-menu'
//     menu.classList.remove('hidden-element');
//     close.classList.remove('hidden-element');
//     // Cache le bouton 'open-menu' en ajoutant la classe 'hidden'
//     open.classList.add('hidden-element');
// });

// // Ajoute un écouteur d'événement 'click' au bouton 'close-menu'
// close.addEventListener('click', (e) => {
//     // Cache le menu en ajoutant la classe 'hidden' et affiche le bouton 'open-menu'
//     menu.classList.add('hidden-element');
//     open.classList.remove('hidden-element');
//     // Cache le bouton 'close-menu' en ajoutant la classe 'hidden'
//     close.classList.add('hidden-element');
// });